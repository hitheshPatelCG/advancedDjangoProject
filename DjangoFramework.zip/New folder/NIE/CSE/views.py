from django.shortcuts import render

# Create your views here.
def home(request):
    return render(request, 'home.html')
def about(request):
    return render(request, 'about.html')
def admissions(request):
    return render(request, 'admissions.html')
def contactus(request):
    return render(request, 'contactus.html')
def products(request):
    return render(request, 'products.html')
def base(request):
    return render(request, 'base.html')